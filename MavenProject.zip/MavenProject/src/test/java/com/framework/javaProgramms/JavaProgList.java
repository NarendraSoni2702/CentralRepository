package com.framework.javaProgramms;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class JavaProgList {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//list can contains duplicate values
		List Al = new ArrayList();
		Al.add("fghfh");
		Al.add(111);
		
		System.out.println(Al);
		
		for (Object l:Al)
		{
			System.out.println(l);
		}
		
		Al.add(0, "lucky");
		Al.add(2, "Micky");
		
		System.out.println(Al);
		
		
		ListIterator itr = Al.listIterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		//without going forward we can not go back
		while(itr.hasPrevious())
		{
			System.out.println(itr.previous());
		}
		
		
		// hashset, hashmap and how map is implemented 

	}

}
