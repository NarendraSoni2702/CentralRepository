package com.framework.javaProgramms;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ActionAPIUsage {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver;
		String ApplicationUrl="https://www.amazon.in/" ;
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		driver.get(ApplicationUrl);
		
		WebElement signin= driver.findElement(By.id("nav-link-yourAccount"));
		
		Actions al = new Actions(driver);
		al.moveToElement(signin).perform();
		
			Thread.sleep(10000);
		
		
		driver.findElement(By.partialLinkText("Order")).click();
		driver.navigate().back();
		Thread.sleep(10000);
		
		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
		
		searchBox.click();
		al.moveToElement(searchBox).keyDown(Keys.SHIFT).sendKeys("shoes").perform();
	
		
		// right click
		al.contextClick();

	}

}
