package com.framework.javaProgramms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DatePickerExample {

	static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		
		
		String ApplicationUrl="https://jqueryui.com/datepicker/" ;

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		driver.get(ApplicationUrl);
		
		driver.switchTo().frame(0);
		
		driver.findElement(By.id("datepicker")).click();
		
		Thread.sleep(3000);
		
		SelectDate("24");

	}

	private static void SelectDate(String date) {
		
		WebElement table = driver.findElement(By.id("ui-datepicker-div"));
		
		List<WebElement> noRows = table.findElements(By.tagName("tr"));
		
		System.out.println(noRows.size());
		
		for(WebElement obj :noRows)
		{
			List<WebElement> noCols = obj.findElements(By.tagName("td"));
			System.out.println(noCols.size());
			
			for (WebElement obj1 :noCols)
			{
				if(obj1.getText().equals(date))
				{
					obj1.click();
					break;
				}
			}
		}
	}

}
