package com.MutualFund.Test.Traning;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class GroupingTestCase {
	
	@Test(groups="sanity")
	public void sum()
	{
		System.out.println("Sum Required");
	}
	
	@Test(groups="Regression")
	public void Mul()
	{
		System.out.println("Mul Required");
	}
	
	@Test(groups={"sanity","functional"})
	public void calc()
	{
		System.out.println("Calc Required");
	}
	
	@Test(groups={"Regression","functional"})
	public void devide()
	{
		System.out.println("Devide Required");
	}

}
