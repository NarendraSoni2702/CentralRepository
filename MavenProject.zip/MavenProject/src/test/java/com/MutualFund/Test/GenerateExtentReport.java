package com.MutualFund.Test;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import com.framework.base.BaseTest;

public class GenerateExtentReport extends BaseTest{
	
	
	@Test
	public void demoTestPass()
	{
		test =extent.createTest("demoTestPass", "This is Demo Test");
		test.log(Status.INFO, "current Test will be for validation");
		Assert.assertTrue(true);
	}
	
}