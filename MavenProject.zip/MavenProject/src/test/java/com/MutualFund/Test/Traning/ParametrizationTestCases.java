package com.MutualFund.Test.Traning;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParametrizationTestCases {
	
	@Parameters({"username","password"})
	@Test
	public void login(String uid, String pwd)
	{
		System.out.println("username is :"+uid);
		System.out.println("password is :"+pwd);
	}

}
