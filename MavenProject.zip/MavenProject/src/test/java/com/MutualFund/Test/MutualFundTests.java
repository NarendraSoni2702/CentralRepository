package com.MutualFund.Test;

import org.testng.annotations.Test;
import com.MutualFund.PO.MutualFundLoginPage;
import com.aventstack.extentreports.Status;
import com.framework.base.BaseTest;
import com.framework.utilities.ExcelDataReadWrite;

import junit.framework.Assert;

import java.lang.reflect.Method;
import java.util.HashMap;


public class MutualFundTests extends BaseTest{
	
	
  @Test(dataProvider="InputData" ,groups="Sanity", description="SheetName=UserLogin, TestCase Description only")
  public void MutualFundLogin(Method m,String TC_ID,HashMap<String,String> InputData) {
	  
	  System.out.println("Test Start");
	  test =extent.createTest(InputData.get("TestCaseID"), InputData.get("TestCaseDescription"));
	  test.assignCategory(m.getAnnotation(Test.class).groups());
	  //MutualFundLoginPage mfLoginpage= new MutualFundLoginPage(driver,ConfigFileReader.getApplicationUrl());  
	  //mfLoginpage.openMutualFundloginPage(); 
	  
	  //System.out.println("Test Started");
	 
  }
  
  
  @Test(dataProvider="InputData" ,groups="Functional", description="SheetName=UserLogin, TestCase Description only")
  public void SearchPageLogin(Method m,String TC_ID,HashMap<String,String> InputData) {
	  
	  System.out.println("Test Start");
	  test =extent.createTest(InputData.get("TestCaseID"), InputData.get("TestCaseDescription"));
	 // test.assignCategory(m.getAnnotation(Test.class).groups());
	  test.fail("This test case fail");
	  test.log(Status.INFO, "<div><h1>Header Will Print Here<h1><div>");
	  
	  
	  //MutualFundLoginPage mfLoginpage= new MutualFundLoginPage(driver,ConfigFileReader.getApplicationUrl());  
	  //mfLoginpage.openMutualFundloginPage(); 
	  
	  //System.out.println("Test Started");
	 
  }
  
  
  /* String expectedTitlePage="xxxxxxxxxxyxxx";
  String correctProfileName ="xxxsxsdsd";
  mfLoginpage.fillUserDetails("xyz", "xyz");
  // click sign in button and wait till page load
  MutualFundProfilePage mfProfilePage=mfLoginpage.clickOnSignInButton();
  mfProfilePage.waitForMutualFundProfilePageToLoad();
  String actualTitle = mfProfilePage.getTitle();
  Assert.assertTrue(actualTitle.equalsIgnoreCase(expectedTitlePage), "Page Title is not expected");
  Assert.assertTrue(mfProfilePage.isCorrectProfileLoaded(correctProfileName), "Profile Name is not correct");
  //verification
*/	 
}
