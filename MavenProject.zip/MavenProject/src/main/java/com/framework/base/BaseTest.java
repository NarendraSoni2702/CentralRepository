package com.framework.base;

import java.io.BufferedReader;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.framework.utilities.ExcelDataReadWrite;


public class BaseTest {

	protected static WebDriver driver;
	protected static ExtentHtmlReporter htmlReporter;
	protected static ExtentReports extent;
	protected static ExtentTest test;
	protected static String reportLocation;
	protected static ExcelDataReadWrite dataReader;
	protected static ConfigFileReader ConfigFileReader;
	protected static final String SourceFolder;


	static{
		
		if (System.getProperty("user.dir").contains("target"))
		{
			SourceFolder=System.getProperty("user.dir").replace("/target", "");
		}
		else
		{
			SourceFolder=System.getProperty("user.dir");
		}
		
		try {
			ConfigFileReader = new ConfigFileReader(SourceFolder);
			dataReader = new ExcelDataReadWrite(ConfigFileReader.getExcelFilePath());
			dataReader.readExcelData();
			
			Calendar calender = Calendar.getInstance();
			SimpleDateFormat formater = new SimpleDateFormat("dd_mm_yyyy_hh_mm_ss");
			
			
			reportLocation=SourceFolder+"/Automation_Reports/"+ConfigFileReader.getApplicationName()+"_"+
						formater.format(calender.getTime())+".html";
			
			htmlReporter = new ExtentHtmlReporter(reportLocation);
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("OS", "Win10");

			// make the charts visible on report open
			htmlReporter.config().setChartVisibilityOnOpen(true);

			// report title
			htmlReporter.config().setDocumentTitle(ConfigFileReader.getApplicationName());

			// encoding, default = UTF-8
			htmlReporter.config().setEncoding("UTF-8");
			
			// chart location - top, bottom
			htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);


			htmlReporter.config().setReportName("Automation Report");
			htmlReporter.config().setTheme(Theme.STANDARD);
			
			// add custom javascript
			//htmlreporter.config().setJS("js-string");


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@DataProvider(name="InputData")
	public Object[][] ExcelInputData(Method m) throws Exception {

		String SheetName = m.getAnnotation(Test.class).description().toString().split(",")[0].split("=")[1].trim();
		System.out.println(SheetName);
		Object[][] data = new Object[dataReader.getSheetData(SheetName).size()][2]; // initialize the array dimension
		Set keyset=dataReader.getSheetData(SheetName).keySet();
		Iterator key = keyset.iterator();
		int counter=0;
		while(key.hasNext())
		{
			String TC_ID=key.next().toString();
			data[counter][0] = TC_ID;
			data[counter][1] = dataReader.getSheetData(SheetName).get(TC_ID);
			counter++;
		}
		
		return data;
	}


	@BeforeMethod
	protected void preOperation(Method result)
	{	
		try {

			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void getResult(ITestResult result)
	{
		if(result.getStatus()==ITestResult.SUCCESS){		
			test.log(Status.PASS, result.getName() + " test is pass");
		}else if(result.getStatus()==ITestResult.SKIP){
			test.log(Status.SKIP, result.getName() + "test is skipped and sikp reason is :" + result.getThrowable());
		}else if (result.getStatus()==ITestResult.FAILURE){			
			test.log(Status.FAIL,result.getName() + " test is failed :" + result.getThrowable());
			test.fail(result.getThrowable());
		}else if (result.getStatus()==ITestResult.STARTED){
			test.log(Status.INFO, result.getName() + " test is started");
		}

	}

	@AfterMethod
	protected void postOperation(ITestResult result)
	{
		driver.close();
		getResult(result);
	}

	@AfterClass(alwaysRun=true)
	protected void endTest()
	{
		extent.flush();
	}

	@AfterSuite(alwaysRun =true)
	protected void openReport()
	{	
		//driver.get(reportLocation);
	}

}
