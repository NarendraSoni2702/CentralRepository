package com.framework.base;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
 
public class ConfigFileReader {
	
	private static Properties properties;
	
	private static String SourceFolder;
	
	public ConfigFileReader(String SourceFolder){
		
		ConfigFileReader.SourceFolder=SourceFolder;
		LoadPropertiesFile();
	}
	
	public void LoadPropertiesFile()
	{
		BufferedReader reader;
		try {
			
			reader = new BufferedReader(new FileReader(SourceFolder+"/GlobalConfig/Config.properties"));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Config.properties not found at " + SourceFolder+"/GlobalConfig/Config.properties");
		}		
	}
	
	public String getApplicationName() {
		String ApplicationName = properties.getProperty("ApplicationName");
		if(ApplicationName != null) return ApplicationName;
		else throw new RuntimeException("ApplicationName not specified in the Config.properties file.");
	} 
	
	public String getExcelFilePath(){
		String excelFileName = properties.getProperty("InputExcelFile");
		if(excelFileName!= null) return SourceFolder+"/src/test/resources/InputTestData/"+excelFileName;
		else throw new RuntimeException("excelFileName not specified in the Config.properties file.");		
	}
	
	public String getApplicationUrl() {
		String url = properties.getProperty("ApplicationURL");
		if(url != null) return url;
		else throw new RuntimeException("ApplicationURL not specified in the Config.properties file.");
	} 
}
