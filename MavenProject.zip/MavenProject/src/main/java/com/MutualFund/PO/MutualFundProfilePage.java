package com.MutualFund.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.framework.base.BasePageObject;

public class MutualFundProfilePage extends BasePageObject<MutualFundProfilePage>{
	
	private By editProfile =By.xpath("xpathExpression");
	private By advancedSearch =By.xpath("xpathExpression");
	private By profileName =By.xpath("xpathExpression");
	

	public MutualFundProfilePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public void waitForMutualFundProfilePageToLoad()
	{
		waitForVisibilityOf(editProfile);
		waitForVisibilityOf(advancedSearch, 10);
	}
	
	public boolean isCorrectProfileLoaded(String correctProfilename)
	{
		if(getText(profileName).equals(correctProfilename))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	

}
