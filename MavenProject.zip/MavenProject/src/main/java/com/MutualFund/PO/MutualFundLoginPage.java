package com.MutualFund.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.framework.base.BasePageObject;

public class MutualFundLoginPage extends BasePageObject<MutualFundLoginPage> {

	private static String ApplicationURL;
	
	private By userID =By.xpath("xpathExpression");
	private By password =By.xpath("xpathExpression");
	private By signInButton=By.xpath("xpathExpression");
	
	@SuppressWarnings("static-access")
	public MutualFundLoginPage(WebDriver driver, String ApplicationURL) {
		super(driver);
		this.ApplicationURL=ApplicationURL;
	}
	
	public void openMutualFundloginPage()
	{
		getPage(ApplicationURL);
	}
	
	public void fillUserDetails(String userId, String Password)
	{
		type(userId,userID);
		type(Password, password);
	}
	
	public MutualFundProfilePage clickOnSignInButton()
	{
		click(signInButton);
		return new MutualFundProfilePage(driver);
	}

	
	
	
}
