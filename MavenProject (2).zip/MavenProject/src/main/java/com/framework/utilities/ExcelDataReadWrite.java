package com.framework.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelDataReadWrite {

	public static HashMap<String,HashMap<String, HashMap<String, String>>> getExcelFileData;
	public static String ExcelFilePath;
	
	public ExcelDataReadWrite(String ExcelFilePath)
	{
		this.ExcelFilePath =ExcelFilePath;
	}
	
	public void readExcelData() throws Exception {
		// HashMap for Storing the Data


		getExcelFileData= new HashMap<String, HashMap<String, HashMap<String, String>>>();

		// Create the input stream for Excel file 
		FileInputStream excelfile = new FileInputStream(ExcelFilePath);

		XSSFWorkbook wb = new XSSFWorkbook(excelfile);

		int noOfSheets= wb.getNumberOfSheets();
		for (int i=0; i<noOfSheets;i++)
		{
			String strSheetName =wb.getSheetAt(i).getSheetName();

			XSSFSheet st = wb.getSheetAt(i);
			int rowcount= st.getLastRowNum();		
			// read Header row values
			XSSFRow  HeaderRow = st.getRow(0);

			HashMap<String, HashMap<String, String>> SheetData = new HashMap<String, HashMap<String, String>>();

			for (int j=1; j<=rowcount;j++)
			{
				int colcount= st.getRow(j).getLastCellNum();
				
					HashMap<String, String> Inputdata = new HashMap<String, String>();

					for (int k=0; k<colcount;k++)
					{
						String Colvalue;

						//if (st.getRow(0).getCell(k).toString().equalsIgnoreCase("Status") || st.getRow(0).getCell(k).toString().equalsIgnoreCase("Comments"))
						//{
							//Colvalue= "";  // ignoring values from status and comments column. so that new values can be stored and display
						//}
						//else
						//{
							//Colvalue= st.getRow(j).getCell(k).toString();					
						//}
						String ColumnName=HeaderRow.getCell(k).toString();
						Colvalue= st.getRow(j).getCell(k).toString();
						Inputdata.put(ColumnName, Colvalue);					
					}
					String TC_ID=st.getRow(j).getCell(0).toString();
					SheetData.put(TC_ID, Inputdata);
			}

			getExcelFileData.put(strSheetName, SheetData);
		}
		wb.close();	
		//System.out.println(getExcelFileData.get("UserLogin").get("TC_01").get("UserName"));
		//System.out.println(getExcelFileData.get("ApplicationUrls").get("MutualFund_Application").get("URL"));
	}

	public HashMap<String, HashMap<String, String>> getSheetData(String SheetName) throws Exception
	{
		return getExcelFileData.get(SheetName);	
	}

	public HashMap<String, String> getTestCaseData(String SheetName, String TestCaseName) throws Exception
	{
		return getExcelFileData.get(SheetName).get(TestCaseName);
	}

	public String getColumnData(String SheetName, String TestCaseName,String ColumnData)
	{
		return getExcelFileData.get(SheetName).get(TestCaseName).get(ColumnData);

	}

	
}
