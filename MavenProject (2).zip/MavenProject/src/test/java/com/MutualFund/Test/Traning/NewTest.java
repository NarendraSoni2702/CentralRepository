package com.MutualFund.Test.Traning;

import org.testng.annotations.Test;

import com.framework.base.BaseTest;

public class NewTest extends BaseTest {
  @Test
  public void f() {
	  test = extent.createTest("Basic New Test", "For Validation");
  }
}
