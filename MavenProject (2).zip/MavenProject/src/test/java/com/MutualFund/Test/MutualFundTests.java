package com.MutualFund.Test;

import org.testng.annotations.Test;
import com.MutualFund.PO.MutualFundLoginPage;
import com.framework.base.BaseTest;
import com.framework.utilities.ExcelDataReadWrite;

import junit.framework.Assert;

import java.util.HashMap;


public class MutualFundTests extends BaseTest{
	
	
  @Test(dataProvider="InputData" , description="SheetName=UserLogin, TestCase Description only")
  public void MutualFundLogin(String TC_ID,HashMap<String,String> InputData) {
	  
	  System.out.println("Test Start");
	  test =extent.createTest(InputData.get("TestCaseID"), InputData.get("TestCaseDescription"));
	  //MutualFundLoginPage mfLoginpage= new MutualFundLoginPage(driver,ConfigFileReader.getApplicationUrl());  
	  //mfLoginpage.openMutualFundloginPage(); 
	  
	  //System.out.println("Test Started");
	 
  }
  
  
  /* String expectedTitlePage="xxxxxxxxxxyxxx";
  String correctProfileName ="xxxsxsdsd";
  mfLoginpage.fillUserDetails("xyz", "xyz");
  // click sign in button and wait till page load
  MutualFundProfilePage mfProfilePage=mfLoginpage.clickOnSignInButton();
  mfProfilePage.waitForMutualFundProfilePageToLoad();
  String actualTitle = mfProfilePage.getTitle();
  Assert.assertTrue(actualTitle.equalsIgnoreCase(expectedTitlePage), "Page Title is not expected");
  Assert.assertTrue(mfProfilePage.isCorrectProfileLoaded(correctProfileName), "Profile Name is not correct");
  //verification
*/	 
}
