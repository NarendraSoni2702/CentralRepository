package com.MutualFund.Test.Traning;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.framework.base.BaseTest;

public class TestNG_Features extends BaseTest{

	WebDriver driver;
	String ApplicationUrl="https://www.amazon.in/" ;

	@Test(priority=1)
	public void browser()
	{
		test = extent.createTest("Browser Test", "Browser Test Description");
		System.out.println("Browser launching");

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		driver.get(ApplicationUrl);
	}


	@Test(dependsOnMethods="browser")
	public void Login() throws InterruptedException
	{
		test = extent.createTest("Login Test", "Login Test Description");
		System.out.println("login is successful");
		WebElement signin= driver.findElement(By.id("nav-link-yourAccount"));

		Actions al = new Actions(driver);
		al.moveToElement(signin).perform();

		Thread.sleep(10000);


		driver.findElement(By.partialLinkText("Order")).click();
		driver.navigate().back();
		Thread.sleep(10000);

		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));

		searchBox.click();
		al.moveToElement(searchBox).keyDown(Keys.SHIFT).sendKeys("shoes").perform();

	}

	@Test(dependsOnMethods="Login")
	public void close()
	{
		test = extent.createTest("Close Test", "Close Test Description");
		System.out.println("Browser is closed");
		driver.close();
	}
}
