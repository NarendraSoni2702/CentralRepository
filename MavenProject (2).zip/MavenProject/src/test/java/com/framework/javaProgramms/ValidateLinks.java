package com.framework.javaProgramms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ValidateLinks {

	public static void main(String[] args) throws InterruptedException {
		
	   // link can be define with either a, div, li, ui
		
		WebDriver driver;
		String ApplicationUrl="https://www.amazon.in/" ;
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		driver.get(ApplicationUrl);
		
		List<WebElement> olink=driver.findElements(By.tagName("a"));
		
		String beforetitle =driver.getTitle();
		for (WebElement obj : olink) {
		    
			if(obj.getText().equalsIgnoreCase("Sell"))
			{
				System.out.println(obj.getText());
				obj.click();
				
				if (beforetitle !=driver.getTitle() )
				{
					System.out.println(beforetitle);
					System.out.println(driver.getTitle());
					System.out.println("Test Case passed");
				}
				else
				{
					System.out.println("Sell link not clicked properly");
					System.out.println("Test Case failed");
				}
				
				break;
			}
		}
		
		driver.close();
	}

}
