package com.framework.javaProgramms;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WindowsHandleExample {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver;
		String ApplicationUrl="https://mail.rediff.com/cgi-bin/login.cgi" ;

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		driver.get(ApplicationUrl);
		
		System.out.println("Before Clicking Disclaimer Page Title");
		System.out.println(driver.getTitle());
		driver.findElement(By.linkText("Disclaimer")).click();
		driver.findElement(By.partialLinkText("Privacy")).click();
		
		Set<String> wids = driver.getWindowHandles();
		System.out.println("Total Windows opened :"+wids.size());
		
		Iterator<String> itr =wids.iterator();
			
		String ParentWindow = itr.next();
		System.out.println("ParentWindow :"+ParentWindow.toString());
		
		String ChildWindow1 =itr.next();
		System.out.println("ChildWindow1 :"+ChildWindow1.toString());
		
		String ChildWindow2 =itr.next();
		System.out.println("ChildWindow1 :"+ChildWindow2.toString());
		
		driver.switchTo().window(ChildWindow1);
		System.out.println("After Clicking Privacy policy Page Title");
		System.out.println(driver.getTitle());
		
		driver.switchTo().window(ChildWindow2);
		System.out.println("After Clicking Disclaimer Page Title");
		System.out.println(driver.getTitle());
		
		
		
		
	}
}
