package com.framework.javaProgramms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

public class JPSet {
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		//Covers set and iterator
		
		//Set can not contains duplicate values
		//1. HashSet contains values in unordered sequence
		//2. TreeSet contains values in alphabetical order
		//3. LinkedHashSet contains values the way it is inserted
		Set s = new TreeSet();
		s.add("fghfh");
		
		s.add("lucky");
		
		s.add("Micky");
		
		System.out.println(s);
		
		//only works in forward direction
		Iterator itr=s.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		

	}

}
