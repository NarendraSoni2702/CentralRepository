package com.framework.javaProgramms;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class FramesExample {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver;
		String ApplicationUrl="https://netbanking.hdfcbank.com/netbanking/" ;

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		driver.get(ApplicationUrl);
		
		List<WebElement> noFrames = driver.findElements(By.tagName("frame"));
		
		System.out.println("No Of Frames :"+noFrames.size());
		
		// switch frame via index
		//driver.switchTo().frame(0);
		
		// switch frame via name
		//driver.switchTo().frame("login_page");
		
		// switch frame via webElement
		WebElement loginFrame= driver.findElement(By.name("login_page"));
		driver.switchTo().frame(loginFrame);
		
		driver.findElement(By.name("fldLoginUserId")).sendKeys("375437543");
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		driver.findElement(By.partialLinkText("Privacy")).click();
		
		
		Set<String> wids = driver.getWindowHandles();
		System.out.println("Total Windows opened :"+wids.size());
		
		Iterator<String> itr =wids.iterator();
			
		String ParentWindow = itr.next();
		System.out.println("ParentWindow :"+ParentWindow.toString());
		
		String ChildWindow1 =itr.next();
		System.out.println("ChildWindow1 :"+ChildWindow1.toString());
		
		driver.switchTo().window(ChildWindow1);
		driver.close();
		
		Thread.sleep(10000);
		
		driver.switchTo().window(ParentWindow).close();
		

	}

}
