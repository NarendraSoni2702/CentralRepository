package com.framework.javaProgramms;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class RadioButton {

	public static void main(String[] args) {

		WebDriver driver;
		String ApplicationUrl="http://toolsqa.com/automation-practice-form/";

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/main/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		driver.get(ApplicationUrl);

		// with out using select class
		List<WebElement> dp=driver.findElements(By.xpath("//*[@type='radio']"));

		for(WebElement dpObj:dp)
		{
			System.out.println(dpObj.getAttribute("value"));
		}

	}


}
