package practice.Module;

import org.openqa.selenium.WebDriver;

import practice.PO.NewCompanyPO;
import practice.Utilities.ScreenShots;


public class NewCompanyModule {
	WebDriver driver;
	public NewCompanyModule(WebDriver driver)
	{
		this.driver=driver;
	}

	public void addValuestoNewCompany() throws Exception
	{
		NewCompanyPO newcomPO = new NewCompanyPO(driver);
		newcomPO.selectStatus("Active");
		newcomPO.setCompany_name("Syntel");
		newcomPO.setIndustry1("Atos");
		String rootpath=System.getProperty("user.dir");
		ScreenShots.captureFullPage(driver, rootpath+"/Reports/Screenshots", "FreeCRMScreenshot");
		
	}
	
	
}
