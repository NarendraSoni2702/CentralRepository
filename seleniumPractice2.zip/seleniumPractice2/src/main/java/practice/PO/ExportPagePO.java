package practice.PO;

import org.openqa.selenium.WebDriver;

import practice.base.BasePageObject;

public class ExportPagePO extends BasePageObject{

	public ExportPagePO(WebDriver driver) {
		super(driver);
		this.driver=driver;
		// TODO Auto-generated constructor stub
	}
	
	

}
