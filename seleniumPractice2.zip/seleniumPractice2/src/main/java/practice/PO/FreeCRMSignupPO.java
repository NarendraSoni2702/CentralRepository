package practice.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import practice.base.BasePageObject;

public class FreeCRMSignupPO extends BasePageObject{
	WebDriver driver;

	By payment_plan_id = By.id("payment_plan_id");

	By first_name = By.name("first_name");
	By surname = By.name("surname");
	By email = By.name("email");
	

	public FreeCRMSignupPO(WebDriver driver)
	{
		super(driver);
		this.driver=driver;

	}

	/*public By getPayment_plan_id() {
		return payment_plan_id;
	}

	public void setPayment_plan_id(By payment_plan_id) {
		this.payment_plan_id = payment_plan_id;
	}*/

	public String getFirst_name() {
		return driver.findElement(first_name).getText();
		 
	}

	public void setFirst_name(String firstname) {
		//driver.findElement(first_name).sendKeys(firstname);
		type(first_name,firstname);
	}

	public String getSurname() {
		return driver.findElement(surname).getText();
	}

	public void setSurname(String Lastname) {
		//driver.findElement(surname).sendKeys(Lastname);
		type(surname,Lastname);
	}

	public String getEmail() {
		return driver.findElement(email).getText();
	}

	public void setEmail(String E_mail) {
		driver.findElement(email).sendKeys(E_mail);
		type(email, E_mail);
	}

}
