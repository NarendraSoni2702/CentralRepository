package practice.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Actions;

import practice.base.BasePageObject;

public class FreeCRMHomePO extends BasePageObject{

	WebDriver driver;
	public FreeCRMHomePO(WebDriver driver) {
		super(driver);
		this.driver=driver;
		// TODO Auto-generated constructor stub
	}
	By companyMenuBar=By.xpath("//a[@title='Companies']");
	By newCompanyItem= By.xpath("//a[@title='New Company']");
	By importbtn=By.xpath("//a[@title='Import']");
	By exportbtn=By.xpath("//a[@title='Export']");
	public void switchtoFrame()
	{
		frameSwitching("mainpanel");
	}
	
	public void movetoMenuBar(String typeOfMenuBar)
	{
		if(typeOfMenuBar.equalsIgnoreCase("companies")){
			WebElement elmnt=findElementSafelyByLocator(companyMenuBar);
			Actions action=new Actions(driver);
			action.moveToElement(elmnt).build().perform();
			click(newCompanyItem);		
		}
	}
	
	public void goToImport()
	{
		click(importbtn);
		
	}
	public void gotoExport()
	{
		click(exportbtn);
	}
	
	

}
