package practice.PO;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

//import practice.Utilities.ScreenShots;
import practice.base.BasePageObject;

public class FreeCRMLoginPO extends BasePageObject {
	WebDriver driver;
	public FreeCRMLoginPO(WebDriver driver) {
		super(driver);
		this.driver=driver;
		// TODO Auto-generated constructor stub
	}
	
	By username = By.name("username");
	By password = By.name("password");
	By login = By.xpath("//input[@type='submit']");
	//By login = By.className("btn btn-small");
	
	public String getUsername(String uname) {
		return driver.findElement(username).getText();
	}
	public void setUsername(String uname) {
	 // driver.findElement(username).sendKeys(uname);
	  type(username,uname);
	}
	public String getPassword() {
		return driver.findElement(password).getText();
	}
	public void setPassword(String pword) {
		//driver.findElement(password).sendKeys(pword);
		type(password,pword);
	}
	public By getLogin() {
		return login;
	}
	public void setLogin(){
		//driver.findElement(login).click();
		click(login);
		
	}
	
	
	
}
