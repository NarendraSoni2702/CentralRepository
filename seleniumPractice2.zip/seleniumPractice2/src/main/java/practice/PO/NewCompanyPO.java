package practice.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import practice.Utilities.JavaScriptMethods;
import practice.base.BasePageObject;

public class NewCompanyPO extends BasePageObject{ 
	
	WebDriver driver;
	public NewCompanyPO(WebDriver driver)
	{
		super(driver);
		this.driver=driver;
	}

			By company_nm = By.name("company_name");
			By industry1=By.name("industry");
			By status=By.name("status");
			
			public By getCompany_name() {
				return company_nm;
			}


			public void setCompany_name(String company_name) {
				//this.company_name = company_name;
				//ype(company_nm,company_name);
				WebElement element = findElementSafelyByLocator(company_nm);
				//JavaScriptMethods.highLightElement(driver, element);
				JavaScriptMethods.typeUsingJavaScript(driver, element, company_name);
				JavaScriptMethods.highLightElement(driver, element);
			}


			public By getIndustry1() {
				return industry1;
			}


			public void setIndustry1(String industry) {
				//this.industry1 = industry1;
				//type(industry1,industry);
				
				WebElement element = findElementSafelyByLocator(industry1);
				//JavaScriptMethods.highLightElement(driver, element);
				JavaScriptMethods.typeUsingJavaScript(driver, element, industry);
				JavaScriptMethods.highLightElement(driver, element);
				
			}

			
			
			public void selectStatus(String selctvalue)
			{
				dropdown(status, "selectByValue", selctvalue);
			}
}