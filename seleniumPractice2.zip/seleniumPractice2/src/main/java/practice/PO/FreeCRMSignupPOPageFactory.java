package practice.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class FreeCRMSignupPOPageFactory {
	WebDriver driver;

	By payment_plan_id = By.id("payment_plan_id");

	@FindBy(name="first_name")
	WebElement fname;
	
	@FindBy(how=How.NAME,using="surname")
	WebElement lname;
	
	@FindBy(how=How.NAME,using="email")
	WebElement mail;
	

	public FreeCRMSignupPOPageFactory(WebDriver driver)
	{
		this.driver=driver;

	}

	/*public By getPayment_plan_id() {
		return payment_plan_id;
	}

	public void setPayment_plan_id(By payment_plan_id) {
		this.payment_plan_id = payment_plan_id;
	}*/

	public String getFirst_name() {
		return fname.getText();
		 
	}

	public void setFirst_name(String firstname) {
		fname.sendKeys(firstname);
	}

	public String getSurname() {
		return lname.getText();
	}

	public void setSurname(String Lastname) {
		lname.sendKeys(Lastname);
	}

	public String getEmail() {
		return mail.getText();
	}

	public void setEmail(String E_mail) {
		mail.sendKeys(E_mail);
	}

}
