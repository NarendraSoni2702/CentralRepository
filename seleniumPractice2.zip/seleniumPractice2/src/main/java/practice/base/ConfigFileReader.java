package practice.base;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

//import com.gargoylesoftware.htmlunit.javascript.host.file.FileReader;

public class ConfigFileReader {
	
	Properties propertiesdata;
	public void readconFile()
	{
		String projectFolder=System.getProperty("user.dir");
		String filepath=projectFolder+ "/GlobalConfig/config.properties";
		//FileReader pfile=new FileReader(filepath);
		try {
		FileReader pfile = new FileReader(filepath);
		//BufferedReader reader=new BufferedReader(pfile);
		BufferedReader read=new BufferedReader(pfile);
		propertiesdata=new Properties();
		propertiesdata.load(read);
		read.close();
		propertiesdata.getProperty("Browser");
		System.out.println(propertiesdata.getProperty("Browser"));
		System.out.println(propertiesdata.getProperty("URL"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public String getBrowser()
	{
		String Browser= propertiesdata.getProperty("Browser");
		if(Browser!=null)
			return Browser;
		else
			throw new RuntimeException("Browser not defined");
		
	}
	public String getURL()
	{
		String URL= propertiesdata.getProperty("URL");
		if(URL!=null)
		return URL;
		else
			throw new RuntimeException("URL is not mentioned");
		
	}
}
