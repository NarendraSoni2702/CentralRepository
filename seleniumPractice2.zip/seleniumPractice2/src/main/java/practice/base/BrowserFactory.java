package practice.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserFactory {
	static String projectdirectory=System.getProperty("user.dir");
	static WebDriver driver;
	
	public static WebDriver initializeBrowser(String BrowserType, String appurl) {
		if (BrowserType.equalsIgnoreCase("chrome")) 
		{
			System.setProperty("webdriver.chrome.driver",projectdirectory+"/Drivers/chromedriver.exe");
			driver=new ChromeDriver();
			driver.get(appurl);
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);

		} else if (BrowserType.equalsIgnoreCase("firefox")) 
		{
			System.setProperty("webdriver.Firefox.driver",projectdirectory+"/Drivers/firefoxdriver.exe");
			driver=new FirefoxDriver();
			driver.get(appurl);
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);

		} else if (BrowserType.equalsIgnoreCase("InternetExplorer")) 
		{
			System.setProperty("WebDriver.ie.driver",projectdirectory+"/Drivers/chromedriver.exe");
			//driver=new IEDriver;
			driver.get(appurl);
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		}
		
		return driver;
	}

}
