package practice.base;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;



import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;


public class BasePageObject {
	public WebDriver driver;

	public BasePageObject(WebDriver driver) {
		this.driver = driver;
	}

	public void type(By locator,String value)
	{
		findElementSafelyByLocator(locator).sendKeys(value);
	}
	
	public void click(By locator){
		findElementSafelyByLocator(locator).click();
	}
	
	public void frameSwitching(String framename)
	{
		driver.switchTo().frame(framename);
	}
	
	public void dropdown(By locator, String ByMethod, String value)
	{
		WebElement elmnt= findElementSafelyByLocator(locator);
		Select s1= new Select(elmnt);
		
		switch(ByMethod)
		{
		case "selectByIndex":
			s1.selectByIndex(Integer.parseInt(value));
			
		case "selectByValue":
			s1.selectByValue(value);
			
		case "selectByVisibleText":
			s1.selectByVisibleText(value);
		}
	}
	
	public WebElement findElementSafelyByLocator(final By locator)
	{
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
			       .withTimeout(40, TimeUnit.SECONDS)
			       .pollingEvery(5, TimeUnit.SECONDS)
			       .ignoring(NoSuchElementException.class);
		
		WebElement element = wait.until(new Function<WebDriver, WebElement>() 
		{
			public WebElement apply(WebDriver driver)
			{
				return driver.findElement(locator);
			}
		});
		return element;
	}
}
