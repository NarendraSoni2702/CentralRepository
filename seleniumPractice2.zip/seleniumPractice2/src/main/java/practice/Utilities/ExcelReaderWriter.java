package practice.Utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReaderWriter {

	LinkedHashMap<String, LinkedHashMap<Integer, LinkedHashMap<String, String>>> getFileData;
	public void readExcelData() throws IOException {
		String rootFolder = System.getProperty("user.dir");
		String FilePath = rootFolder +"/TestData/InputData.xlsx";

		// create the input stream for excel file
		FileInputStream excelfile = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(excelfile);
		int noofSheet = workbook.getNumberOfSheets();
		getFileData = new LinkedHashMap<String, LinkedHashMap<Integer, LinkedHashMap<String, String>>>();
		for (int i = 0; i < noofSheet; i++) {
			String s = workbook.getSheetAt(i).getSheetName();
			System.out.println(s);

			

			//if (s.equalsIgnoreCase("Login")) {
				XSSFSheet st = workbook.getSheetAt(i);
				int rowcount = st.getPhysicalNumberOfRows();
				System.out.println(rowcount);

				XSSFRow headerObj = st.getRow(0);
				LinkedHashMap<Integer, LinkedHashMap<String, String>> SheetMap = new LinkedHashMap<Integer, LinkedHashMap<String, String>>();
				for (int j = 1; j < rowcount; j++) // change counter
				{
					XSSFRow rowObj = st.getRow(j);
					int cellCount = rowObj.getLastCellNum();
					System.out.println(cellCount);
					LinkedHashMap<String, String> rowMap = new LinkedHashMap<String, String>();
					for (int k = 0; k < cellCount; k++) {
						XSSFCell headerCellObj = headerObj.getCell(k);

						String headerValue = headerCellObj.toString();

						XSSFCell cellObj = rowObj.getCell(k);
						// System.out.println(cellObj.toString()); //convert any
						// value to string
						String colValue = cellObj.toString();

					}

					System.out.println(rowMap);
					SheetMap.put(j, rowMap);
					// System.out.println();
				}
				System.out.println(SheetMap);
				getFileData.put(s, SheetMap);				

			}
			System.out.println(getFileData);
		}

		public LinkedHashMap<Integer, LinkedHashMap<String, String>> getSheetData (String sheetname)
		{
			return getFileData.get(sheetname);
		}
		public LinkedHashMap<String, String> getTestCaseData(String Sheetname, int TC_ID)
		{
			return getFileData.get(Sheetname).get(TC_ID);
			
		}
		
		public String getColumnData(String Sheetname, int TC_ID, String colname)
		{
			return getFileData.get(Sheetname).get(TC_ID).get(colname);
		}
		
	}
	

