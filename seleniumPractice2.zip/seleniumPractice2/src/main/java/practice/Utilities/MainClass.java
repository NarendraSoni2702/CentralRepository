package practice.Utilities;

import java.io.IOException;

public class MainClass {

	public static void main(String[] args) throws Exception {
		ExcelReaderWriter excelread = new ExcelReaderWriter();
		excelread.readExcelData();
		
		excelread.getSheetData("Sheet1");
		excelread.getTestCaseData("Sheet1", 2);
		excelread.getColumnData("Sheet1", 2, "ID");
		

	}

}
