package cascademethod;

public class MainClass {

	public static void main(String[] args) {
ClassC mainobj= new ClassC();
mainobj.methodC().methodB().methodA();
		
	}

}
