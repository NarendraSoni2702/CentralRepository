package cascademethod;

public class ClassA {

	public void methodA()
	{
		String name= "Vishal Pund";
		String[] arr=name.split("");
		
		System.out.println("Class A Executed");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		for(int i=arr.length-1;i>=0;i--)
		{
			System.out.println(arr[i]);
		}
		
		
	}
	
}
