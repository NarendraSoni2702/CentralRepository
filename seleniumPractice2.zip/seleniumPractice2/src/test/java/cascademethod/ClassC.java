package cascademethod;

public class ClassC {

	public ClassB methodC()
	{
		System.out.println("Class C Executed");
		return new ClassB();
		
	}
}
