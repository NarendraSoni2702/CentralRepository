package cascademethod;

public class CharAtDemo {

	public static void main(String[] args) {
		String name= "Vishal Pund syntel";
		//name.charAt(4);
		name.length();
		for(int i=0;i<=name.length()-1;i++)
		{
			System.out.println(name.charAt(i));	
		}
		
	}

}
