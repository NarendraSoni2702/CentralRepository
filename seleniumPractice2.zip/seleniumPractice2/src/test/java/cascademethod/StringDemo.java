package cascademethod;

public class StringDemo {

	public static void main(String[] args) {
		String name= "Vishal Pund syntel";
		String revrerse = "";
		String[] arr=name.split("");
		
		//name.charAt(6);
		
		
		int count=0;
		for(int i=0;i<arr.length;i++)
		{
			
			if(arr[i].equals("s"))
			{
				count++;
			}
			
		}
		System.out.println(count);
		
		/*for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
			
			revrerse=arr[i]+revrerse;//to print reverse
			
		}
		
		
		for(int i=arr.length-1;i>=0;i--)
		{
			System.out.println(arr[i]);
		    revrerse=revrerse+arr[i];
		    
		}*/
	//	System.out.println("reverse "+revrerse);*/
		

	}

}
