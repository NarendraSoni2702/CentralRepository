package cascademethod;

public class ClassB {

	public ClassA methodB()
	{
		System.out.println("Class B Executed");
		return new ClassA();
		
	}
}
