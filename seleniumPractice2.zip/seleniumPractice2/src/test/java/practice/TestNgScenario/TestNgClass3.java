package practice.TestNgScenario;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class TestNgClass3 {
@BeforeSuite
public void beforesuite()
{
	System.out.println("Output of beforesuite");
}
@AfterSuite
public void aftersuite()
{
	System.out.println("Output of aftersuite");
}
@BeforeClass
public void beforeclass()
{
	System.out.println("Output of beforeclass");
}
@AfterClass
public void afterclass()
{
	System.out.println("Output of afterclass");
}
@BeforeTest
public void beforetest()
{
	System.out.println("Output of beforetest");
}
@AfterTest
public void aftertest()
{
	System.out.println("Output of aftertest");
}

@BeforeGroups(groups={"SanityTesting"})
public void beforegroup()
{
	System.out.println("Output of beforegroup");
}

@AfterGroups(groups={"SanityTesting"})
public void aftergroup()
{
	System.out.println("Output of aftergroup");
}

}