package practice.TestNgScenario;

import org.testng.annotations.Test;

import practice.base.ConfigFileReader;

public class mainPropertiesFile {
	@Test
	public void fileread()
	{
		ConfigFileReader conf=new ConfigFileReader();
		conf.readconFile();
		conf.getBrowser();
		conf.getURL();
		System.out.println(conf.getBrowser());
		System.out.println(conf.getURL());
	}
}
