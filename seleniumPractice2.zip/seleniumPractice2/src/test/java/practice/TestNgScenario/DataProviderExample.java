package practice.TestNgScenario;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderExample {

	@Test
	public void p() {
		System.out.println("Output of Method P");
	}

	@Test(dataProvider = "InputData")
	public void abc(String dataread) {
		System.out.println("Output of method C " + dataread);

	}

	@DataProvider(name = "InputData")
	public Object[][] dataProvide() {
		return new Object[][] { { "one" }, { "two" } };

	}
}
