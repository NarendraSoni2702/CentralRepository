package practice.TestNgScenario;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNgClass2 {
	public TestNgClass2(String string) {
		// TODO Auto-generated constructor stub
	}
	@Test
	public void z()
	{
		System.out.println("Output of Method z");
	}
	@Test(priority=2,groups={"SanityTesting"})
	public void v()
	{
		System.out.println("Output of Method v");
	}
	@Test(priority=2,dependsOnMethods="y")
	public void x()
	{
		System.out.println("Output of Method x");	
	}
	@Test(priority=1)
	public void y()
	{
		System.out.println("Output of Method y");
		
	}
	@Test(priority=1,groups={"SanityTesting"})
	public void l()
	{
		System.out.println("Output of Method l");
	}
	
	@BeforeMethod
	public void beforemethod()
	{
		System.out.println("Output of beforemethod");
	}
	
	@AfterMethod
	public void aftermethod()
	{
		System.out.println("Output of aftermethod");
	}
}