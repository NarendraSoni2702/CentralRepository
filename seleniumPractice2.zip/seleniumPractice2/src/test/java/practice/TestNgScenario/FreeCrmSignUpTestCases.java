package practice.TestNgScenario;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import practice.Module.NewCompanyModule;
import practice.PO.FreeCRMHomePO;
import practice.PO.FreeCRMLoginPO;
import practice.PO.FreeCRMSignupPO;
import practice.PO.FreeCRMSignupPOPageFactory;
import practice.PO.ImportPagePO;
import practice.PO.NewCompanyPO;
import practice.Utilities.ScreenShots;
import practice.base.BrowserFactory;

public class FreeCrmSignUpTestCases {
	
	@Test(enabled = false)
	public void freeCrmSignup()
	{
		WebDriver driver=BrowserFactory.initializeBrowser("chrome", "https://www.freecrm.com/register/");
		//Simple way to implement POM
		FreeCRMSignupPO fpo=new FreeCRMSignupPO(driver);
		fpo.setFirst_name("Vishal");
		fpo.setSurname("Pund");
		fpo.setEmail("vishalpund123@gmail.com");
		System.out.println(fpo.getFirst_name());
		
		//Using PageFactory Method---- POM
		FreeCRMSignupPOPageFactory fp=PageFactory.initElements(driver, FreeCRMSignupPOPageFactory.class);
		fp.setFirst_name("Vishal");
		fp.setSurname("Pund");
		fp.setEmail("vishalpund123@gmail.com");
	}
	
	@Test
	public void FreeCRMLogin() throws Exception
	{
		WebDriver driver=BrowserFactory.initializeBrowser("chrome", "https://www.freecrm.com/index.html");
		FreeCRMLoginPO flogin=new FreeCRMLoginPO(driver);
		FreeCRMHomePO fcrmhome = new FreeCRMHomePO(driver);
		ImportPagePO imprtpg= new ImportPagePO(driver);
		NewCompanyModule newcommod=new NewCompanyModule(driver);
		flogin.setUsername("Deepesh");
		flogin.setPassword("Free@1234");
		flogin.setLogin();
		
		
		fcrmhome.switchtoFrame();
		fcrmhome.movetoMenuBar("companies");
		newcommod.addValuestoNewCompany();
		fcrmhome.goToImport();
		imprtpg.setChooseFile();
		
		String rootpath=System.getProperty("user.dir");
		ScreenShots.captureFullPage(driver, rootpath+"/Reports/Screenshots", "FreeCRMScreenshot");
		//fcrmhome.click("New company");
	}
	
	@Test(enabled = false)
	public void companies()
	{
		WebDriver driver=BrowserFactory.initializeBrowser("chrome", "https://www.freecrm.com/index.html");
		FreeCRMHomePO fcrmhome = new FreeCRMHomePO(driver);
		fcrmhome.movetoMenuBar("companies");
	}
	
}