package practice.TestNgScenario;

import org.testng.annotations.Factory;

public class FactoryAnnotationExample {
	@Factory
	public Object factoryMethod()
	{
		Object[] tests=new Object[3];
		tests[0]=new TestNGClass1("Chrome");
		tests[1]=new TestNgClass2("Internet Explorer");
		tests[2]=new TestNgClass3();
		return tests;
		
	}

}
