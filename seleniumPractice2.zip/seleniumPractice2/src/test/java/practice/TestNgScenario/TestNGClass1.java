package practice.TestNgScenario;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNGClass1 extends TestNgClass3{
	
	public String Browsername; 
	public TestNGClass1(String string) {
		// TODO Auto-generated constructor stub
		this.Browsername=string;
	}
	@Test(priority=2,groups={"SanityTesting"})
	public void e()
	{
		System.out.println("Output of Method e");
	}
	@Test(priority=2,dependsOnMethods="d",groups={"smoketesting"})
	public void a()
	{
		System.out.println("Output of Method a");	
		System.out.println(Browsername);
	}
	@Test(priority=1,groups={"smoketesting"})	
	public void d()
	{		
		System.out.println("Output of Method d");
	}
	@Parameters({"Browser"})
	@Test(groups={"SanityTesting"},expectedExceptions=ArithmeticException.class)
	public void f(String f)
	{
		int a=10;
		System.out.println("Output of Method f");
		System.out.println(Browsername);
		int b=a/0;
		System.out.println(b);
		
		System.out.println(f);
	}

}
