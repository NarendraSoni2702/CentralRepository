package practice.seleniumPractice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ToolsQAPractice {

	public static void main(String args[]) throws Exception
	{
		String projectdirectory=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectdirectory+"/Drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://toolsqa.com/automation-practice-form/");
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		Thread.sleep(8000);
		driver.findElement(By.linkText("Partial Link Test")).click();
		
		//driver.findElement(By.xpath("//strong[@text()='Partial Link Test']")).click();
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Vishal");
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Pund");
		driver.findElement(By.xpath("//input[@id='sex-0']")).click();
		driver.findElement(By.xpath("//input[@id='exp-2']")).click();
		driver.findElement(By.xpath("//input[@id='datepicker']")).sendKeys("09/01/2018");
		driver.findElement(By.xpath("//input[@id='profession-1']")).click();
		driver.findElement(By.xpath("//input[@id='tool-2']")).click();
		
		driver.findElement(By.xpath("//select[@id='continents']")).click();
		Select s = new Select(driver.findElement(By.xpath("//select[@id='continents']")));
		s.selectByIndex(2);
		Select s1=new Select(driver.findElement(By.xpath("//div[@class='controls']/child::select[@id='selenium_commands']")));
		s1.selectByVisibleText("Switch Commands");
		
		
		//driver.close();
		
		
		
		
	}
	
	
	 
}
