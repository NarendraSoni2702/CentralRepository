package practice.seleniumPractice;

public abstract class anonymousAbstarct {
	public void display()
	{
		System.out.println("Display Method");
	}
	public void show()
	{
		System.out.println("Show method");
	}
	
	public abstract void divide();
	public abstract void abstractdemo();

}
