package practice.seleniumPractice;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FrameClass {

	public static void main(String[] args) {
		String projectfolder = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectfolder + "/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://toolsqa.com/iframe-practice-page/");

		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);

		int framecount = driver.findElements(By.tagName("iframe")).size();
		System.out.println(framecount);

		List<WebElement> frameList = driver.findElements(By.tagName("iframe"));

		for (int i = 0; i < frameList.size(); i++) {
			//String frameId = frameList.get(i).getAttribute("id");
			String frameId = frameList.get(i).getAttribute("name");
			System.out.println(frameId);
		}
		driver.switchTo().frame(frameList.get(0));
		//driver.switchTo().frame("iframe1");
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Vishal");
		driver.switchTo().defaultContent();
		driver.switchTo().frame(frameList.get(1));
		driver.findElement(By.xpath("//a[@href='#tabs-3']")).click();
		
		
	}

}
