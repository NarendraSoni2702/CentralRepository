package practice.seleniumPractice;

public interface AnnoyInterface {

	public void add();
	public void subtract();
	public void mul();
	
}
