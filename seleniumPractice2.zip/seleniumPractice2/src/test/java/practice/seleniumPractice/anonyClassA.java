package practice.seleniumPractice;

public class anonyClassA {
	
	int i;
	public void add()
	{
		int a=10+20;
		System.out.println(a);
	}
	public void sum()
	{
		System.out.println("override");
	}

}
