package practice.seleniumPractice;

public class anonymousClass {

	public static void main(String[] args) {

		anonyClassA a=new anonyClassA(){
			public void sum()
			{
				System.out.println("SUM Override");
			}
		};

		a.sum();
		a.add();

		AnnoyInterface intrfc =new AnnoyInterface()
		{
			public void add()
			{
				System.out.println("Add method execute");
			}

			public void subtract() {
				// TODO Auto-generated method stub

			}

			public void mul() {
				// TODO Auto-generated method stub
				System.out.println("mul function ");
			}
		};

		intrfc.subtract();
		
		anonymousAbstarct ab1=new anonymousAbstarct()
		{

			@Override
			public void divide() {
				// TODO Auto-generated method stub
				System.out.println("Divide Execute");
			}

			@Override
			public void abstractdemo() {
				// TODO Auto-generated method stub
				System.out.println("abstractdemo");
			}

		};

		ab1.divide();
		ab1.abstractdemo();
	}

}
