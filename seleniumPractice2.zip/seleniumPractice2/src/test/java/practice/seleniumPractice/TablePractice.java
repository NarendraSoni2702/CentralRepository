package practice.seleniumPractice;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TablePractice {

	public static void main(String args[]) throws Exception
	{
		String projectdirectory=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectdirectory+"/Drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.cricbuzz.com/cricket-series/2735/asia-cup-2018/points-table");
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		Thread.sleep(8000);
		
		WebElement tableobj=driver.findElement(By.xpath("//table[@class='table cb-srs-pnts'][1]"));
		
		/*WebElement headerobj=tableobj.findElement(By.tagName("thead"));//we can do same for Body 
		WebElement headerRowobj=headerobj.findElement(By.tagName("tr"));
				
		List<WebElement> thlist=headerRowobj.findElements(By.tagName("th"));
		
		System.out.println(thlist.size());
		
		List<WebElement> tdlist=headerRowobj.findElements(By.tagName("td"));
		System.out.println(tdlist.size());
		*/
/*		for(int i=0;i<thlist.size();i++)
		{
			
			WebElement hrow= thlist.get(i);
			
			for (int k=0; k<tdlist.size();k++)
			{
				WebElement cellobj = tdlist.get(k);
				System.out.println(cellobj.getText());
			}
			
		}
		*/
		WebElement bodyobj=tableobj.findElement(By.tagName("tbody"));
		List<WebElement> bodyrow=bodyobj.findElements(By.tagName("tr"));
		System.out.println(bodyrow.size());
		//List<WebElement> tdrow=bodyrow.findElements(By.tagName("td"));
		//System.out.println(tdrow.size());
		
		/*
		for (int i=0;i<bodyrow.size();i++)
		{
			//WebElement bdyrow=bodyrow.get(i);
			
			for (int k=0;k<tdrow.size();k++)
			{
				WebElement rowobjj=tdrow.get(k);
				System.out.println(rowobjj.getText());
			}
		}
		*/
		
	}
}
