package practice.seleniumPractice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
//import org.apache.commons.lang3.ThreadUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class WindowHandeler {

	public static void main(String[] args) throws Exception {
		String projectfolder=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectfolder+"/Drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://register.rediff.com/register/register.php?FormName=user_details");
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);

		String parentwindow = driver.getWindowHandle();
		System.out.println(parentwindow);
		
		
		//driver.findElement(By.xpath("//);
		driver.findElement(By.xpath("//a[text()='terms and conditions']")).click();

		driver.findElement(By.xpath("//a[text()='privacy policy']")).click();


		Set<String> WindowSet=driver.getWindowHandles();
		System.out.println(WindowSet);
   
      List<String> windowList=new ArrayList<String>(WindowSet);
      
      Thread.sleep(8000);
      driver.switchTo().window(windowList.get(1)).close();;
      
      Thread.sleep(4000);
     
      driver.switchTo().window(windowList.get(2));
      Thread.sleep(8000);
      driver.findElement(By.xpath("//div[@class='floatR']/input[@type='button'][@value='OK']")).click();
      driver.switchTo().window(windowList.get(0)).close();
		
	  Iterator<String> itr=WindowSet.iterator();

/*		while(itr.hasNext())
		{
			String windowAddress=itr.next();
			System.out.println(windowAddress);
			if(!(parentwindow).equals(windowAddress))
			{
				System.out.println("ChildAddress"+windowAddress);
//				driver.switchTo().window(windowAddress).findElement(By.xpath("//div[@class='floatR']/input[@type='button']")).click();
				driver.switchTo().window(windowAddress).close();
			}
		}
*/



//		driver.switchTo().window(parentwindow).close();
	//	driver.close();






	}

}
